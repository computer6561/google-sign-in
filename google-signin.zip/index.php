<?php
session_start();

echo $_SESSION['name']."</br>";
echo $_SESSION['email']."</br>";
echo $_SESSION['gender']."</br>";
echo $_SESSION['familyName']."</br>";
echo $_SESSION['givenName']."</br>";

echo "<a href='$_SESSION[picture]'><img src='$_SESSION[picture]' width='200px' height='250px'></a>";

echo "<pre>";
 var_dump($_SESSION['userdata']);

?>