<?php
require_once('google.php');


 if(isset($_GET['code'])){
	$token =  $client->fetchAccessTokenWithAuthCode($_GET['code']);
	$_SESSION['access_token'] = $token;
	
 }
 
 $data = new Google_Service_Oauth2($client);
 
 $userdata = $data->userinfo_v2_me->get();
 
 $_SESSION['name'] = $userdata['name'];
 $_SESSION['email'] =$userdata['email'];
 $_SESSION['gender'] =$userdata['gender'];
 $_SESSION['picture'] =$userdata['picture'];
 $_SESSION['familyName'] =$userdata['familyName'];
 $_SESSION['givenName'] =$userdata['givenName'];
 $_SESSION['userdata'] = $userdata;
 header('Location: index.php');
 exit();

?>