<?php
require_once('google.php');

 $loginUrl = $client->createAuthUrl();

?>
<html>
<head>
<title>Google Login</title>
</head>
<body>

<input type='button' onclick="window.location = '<?php echo $loginUrl; ?>'" value='Google Login'>
</body>

</html>