<?php
session_start();
require_once('vendor/autoload.php');

  $client = new Google_Client();
  
  $client->setClientId('client-id');
  $client->setClientSecret('client-secret');
  $client->setApplicationName("application-name");
  $client->setRedirectUri('redirect-url');
  $client->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email ");
  
?>